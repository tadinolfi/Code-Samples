﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.IO;
using System.Net.Mail;

public partial class control_Login : AZHCore.AZHPage 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}
